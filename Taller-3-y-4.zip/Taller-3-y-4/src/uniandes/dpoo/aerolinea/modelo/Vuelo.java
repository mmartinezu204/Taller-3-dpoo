package uniandes.dpoo.aerolinea.modelo;

public class Vuelo {
	private String fecha;
	private Avion avion;
	private Ruta ruta;
	
	
	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		super();
		this.fecha = fecha;
		this.avion = avion;
		this.ruta = ruta;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public Avion getAvion() {
		return avion;
	}
	public void setAvion(Avion avion) {
		this.avion = avion;
	}
	public Ruta getRuta() {
		return ruta;
	}
	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	
	
}
